package com.example.storyapp.presentation.domain.entity

data class UserEntity(
    val id: String,
    val name: String,
    val token: String,
)