package com.example.storyapp.presentation.domain.contract

interface LogoutUseCaseContract {
    suspend operator fun invoke()

}